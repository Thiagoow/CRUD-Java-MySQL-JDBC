/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dm20241m.controller;

import dm20241m.model.bean.Sistema;
import dm20241m.model.dao.DaoSistema;

import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author thiag
 */
public class ControllerSistema {
    DaoSistema daoSis;
    
    public Sistema inserir(Sistema sisEnt) throws SQLException, ClassNotFoundException {
        daoSis = new DaoSistema();
        return daoSis.inserir(sisEnt);
    }

    public Sistema alterar(Sistema sisEnt) throws SQLException, ClassNotFoundException {
        daoSis = new DaoSistema();
        return daoSis.alterar(sisEnt);
    }

    public Sistema excluir(Sistema sisEnt) throws SQLException, ClassNotFoundException {
        daoSis = new DaoSistema();
        return daoSis.excluir(sisEnt);
    }

    public Sistema buscar(Sistema sisEnt) throws SQLException, ClassNotFoundException {
        daoSis = new DaoSistema();
        Sistema sisSaida = daoSis.buscar(sisEnt);
        return sisSaida;
    }

    public List<Sistema> listar(Sistema sisEnt) throws SQLException, ClassNotFoundException {
        daoSis = new DaoSistema();
        List<Sistema> listaSistema = daoSis.listar(sisEnt);
        return listaSistema;
    }
}
