/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dm20241m.controller;

import dm20241m.model.bean.UsuarioSistema;
import dm20241m.model.dao.DaoUsuarioSistema;

import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author thiag
 */
public class ControllerUsuarioSistema {
    DaoUsuarioSistema daoUsSis;

    public UsuarioSistema inserir(UsuarioSistema usEnt) throws SQLException, ClassNotFoundException {
        daoUsSis = new DaoUsuarioSistema();
        return daoUsSis.inserir(usEnt);
    }

    public UsuarioSistema alterar(UsuarioSistema usEnt) throws SQLException, ClassNotFoundException {
        daoUsSis = new DaoUsuarioSistema();
        return daoUsSis.alterar(usEnt);
    }

    public UsuarioSistema buscar(int id) throws SQLException, ClassNotFoundException {
        daoUsSis = new DaoUsuarioSistema();
        return daoUsSis.buscar(id);
    }

    public List<UsuarioSistema> listar() throws SQLException, ClassNotFoundException {
        daoUsSis = new DaoUsuarioSistema();
        return daoUsSis.listar();
    }

    public void excluir(int id) throws SQLException, ClassNotFoundException {
        daoUsSis = new DaoUsuarioSistema();
        daoUsSis.excluir(id);
    }
}
