/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dm20241m.controller;

import dm20241m.model.bean.Manutencao;
import dm20241m.model.dao.DaoManutencao;

import java.sql.SQLException;
import java.util.List;

/**
 *
 * @author thiag
 */
public class ControllerManutencao {
    DaoManutencao daoManut;
            
    public Manutencao inserir(Manutencao manEnt) throws SQLException, ClassNotFoundException {
        daoManut = new DaoManutencao();
        return daoManut.inserir(manEnt);
    }

    public Manutencao alterar(Manutencao manEnt) throws SQLException, ClassNotFoundException {
        daoManut = new DaoManutencao();
        return daoManut.alterar(manEnt);
    }

    public Manutencao excluir(Manutencao manEnt) throws SQLException, ClassNotFoundException {
        daoManut = new DaoManutencao();
        return daoManut.excluir(manEnt);
    }

    public Manutencao buscar(Manutencao manEnt) throws SQLException, ClassNotFoundException {
        daoManut = new DaoManutencao();
        Manutencao mantSaida = daoManut.buscar(manEnt);
        return mantSaida;
    }

    public List<Manutencao> listar(Manutencao manEnt) throws SQLException, ClassNotFoundException {
        daoManut = new DaoManutencao();
        List<Manutencao> listaManutencao = daoManut.listar(manEnt);
        return listaManutencao;
    }
}
