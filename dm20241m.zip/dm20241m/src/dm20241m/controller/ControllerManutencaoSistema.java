/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dm20241m.controller;

import dm20241m.model.bean.Manutencao;
import dm20241m.model.bean.Sistema;
import dm20241m.model.bean.ManutencaoSistema;
import dm20241m.model.dao.DaoManutencaoSistema;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author lab04aluno
 */
public class ControllerManutencaoSistema {
    DaoManutencaoSistema daoManSis;
    ControllerManutencao contMant;
    ControllerSistema contSist;

    public ManutencaoSistema inserir(ManutencaoSistema msEnt) throws SQLException, ClassNotFoundException {
        daoManSis = new DaoManutencaoSistema();
        return daoManSis.inserir(msEnt);
    }

    public ManutencaoSistema alterar(ManutencaoSistema msEnt) throws SQLException, ClassNotFoundException {
        daoManSis = new DaoManutencaoSistema();
        return daoManSis.alterar(msEnt);
    }

    public ManutencaoSistema buscar(ManutencaoSistema msEnt) throws SQLException, ClassNotFoundException {
        daoManSis = new DaoManutencaoSistema();
        ManutencaoSistema msSaida = daoManSis.buscar(msEnt);
        
        Manutencao mant = new Manutencao(msSaida.getIdM());
        contMant = new ControllerManutencao();
        msSaida.setManut(contMant.buscar(mant));
        
        Sistema sist = new Sistema(msSaida.getIdS());
        contSist = new ControllerSistema();
        msSaida.setSist(contSist.buscar(sist));
        
        return msSaida;
    }

    public List<ManutencaoSistema> listar(ManutencaoSistema msEnt) throws SQLException, ClassNotFoundException {
        daoManSis = new DaoManutencaoSistema();
        List<ManutencaoSistema> listaUsuarioAux = daoManSis.listar(msEnt);
        List<ManutencaoSistema> listaUsuario = new ArrayList<>();
        for(ManutencaoSistema manSis: listaUsuarioAux) {
            listaUsuario.add(buscar(manSis));
        }
        return listaUsuario;
    }

    public void excluir(int id) throws SQLException, ClassNotFoundException {
        daoManSis = new DaoManutencaoSistema();
        daoManSis.excluir(id);
    }
}
