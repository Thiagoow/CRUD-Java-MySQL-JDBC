/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dm20241m.view;

import dm20241m.controller.ControllerManutencaoSistema;
import dm20241m.model.bean.ManutencaoSistema;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author thiag
 */
public class ManterManutencaoSistema {
    
    public static void menu() throws SQLException, ClassNotFoundException {
        String msg = " 1 - Inserir \n 2 - Alterar \n 3 - Buscar \n 4 - Excluir \n 5 - Listar ";
        int num = Integer.parseInt(JOptionPane.showInputDialog(msg));
        switch (num) {
            case 1:
                inserir();
                break;
            case 2:
                alterar();
                break;
            case 3:
                buscar();
                break;
            case 4:
                excluir();
                break;
            case 5:
                listar();
                break;
            default:
                System.out.println("Opção inválida");
        }
    }

    private static void inserir() throws SQLException, ClassNotFoundException {
        int idM = Integer.parseInt(JOptionPane.showInputDialog("ID da manutenção"));
        int idS = Integer.parseInt(JOptionPane.showInputDialog("ID do sistema"));
        String obs = JOptionPane.showInputDialog("Nova observação");

        ManutencaoSistema usEnt = new ManutencaoSistema(idM, idS, obs);
        ControllerManutencaoSistema contManSis = new ControllerManutencaoSistema();
        ManutencaoSistema msSaida = contManSis.inserir(usEnt);
        JOptionPane.showMessageDialog(null, msSaida.toString());
    }

    private static void alterar() throws SQLException, ClassNotFoundException {
        int id = Integer.parseInt(JOptionPane.showInputDialog("ID do registro a ser alterado"));
        int idM = Integer.parseInt(JOptionPane.showInputDialog("Novo ID da manutencao"));
        int idS = Integer.parseInt(JOptionPane.showInputDialog("Novo ID do sistema"));
        String obs = JOptionPane.showInputDialog("Nova observação");

        ManutencaoSistema usEnt = new ManutencaoSistema(id, idM, idS, obs);
        ControllerManutencaoSistema contManSis = new ControllerManutencaoSistema();
        ManutencaoSistema msSaida = contManSis.alterar(usEnt);
        JOptionPane.showMessageDialog(null, msSaida.toString());
    }

    private static void buscar() throws SQLException, ClassNotFoundException {
        int id = Integer.parseInt(JOptionPane.showInputDialog("ID do registro a ser buscado"));

        ManutencaoSistema msEnt = new ManutencaoSistema(id);
        ControllerManutencaoSistema contManSis = new ControllerManutencaoSistema();
        ManutencaoSistema msSaida = contManSis.buscar(msEnt);
        JOptionPane.showMessageDialog(null,msSaida.toString());
        JOptionPane.showMessageDialog(null,msSaida.getManut().toString());
        JOptionPane.showMessageDialog(null,msSaida.getSist().toString());
    }

    private static void excluir() throws SQLException, ClassNotFoundException {
        int id = Integer.parseInt(JOptionPane.showInputDialog("ID do registro a ser excluído"));

        ControllerManutencaoSistema contManSis = new ControllerManutencaoSistema();
        contManSis.excluir(id);
        JOptionPane.showMessageDialog(null, "Registro excluído com sucesso");
    }

    private static void listar() throws SQLException, ClassNotFoundException {
        String obs = JOptionPane.showInputDialog("Observação da Manutenção de Sistema");
        ManutencaoSistema manutSis = new ManutencaoSistema(obs);

        ControllerManutencaoSistema contManSis = new ControllerManutencaoSistema();
        List<ManutencaoSistema> listaManut = contManSis.listar(manutSis);
        for (ManutencaoSistema usuSaida : listaManut) {
            JOptionPane.showMessageDialog(null,usuSaida.toString());
            JOptionPane.showMessageDialog(null,usuSaida.getManut().toString());
            JOptionPane.showMessageDialog(null,usuSaida.getSist().toString());
        }
    }
}
