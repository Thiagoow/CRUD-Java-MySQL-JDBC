/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dm20241m.view;

import dm20241m.controller.ControllerManutencao;
import dm20241m.model.bean.Manutencao;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author thiag
 */
public class ManterManutencao {
    
    public static void menu() throws SQLException, ClassNotFoundException {
        String msg = " 1 - Inserir \n 2 - Alterar \n 3 - Buscar \n 4 - Excluir \n 5 - Listar ";
        int num = Integer.parseInt(JOptionPane.showInputDialog(msg));
        switch (num) {
            case 1:
                inserir();
                break;
            case 2:
                alterar();
                break;
            case 3:
                buscar();
                break;
            case 4:
                excluir();
                break;
            case 5:
                listar();
                break;
            default:
                System.out.println("Opção inválida");
        }
    }

    private static void inserir() throws SQLException, ClassNotFoundException {
        String nome = JOptionPane.showInputDialog("Nome");
        String finalizada = JOptionPane.showInputDialog("Finalizada");

        Manutencao manEnt = new Manutencao(nome, Boolean.parseBoolean(finalizada));
        ControllerManutencao contMant = new ControllerManutencao();
        Manutencao manSaida = contMant.inserir(manEnt);
        JOptionPane.showMessageDialog(null, manSaida.toString());
    }

    private static void alterar() throws SQLException, ClassNotFoundException {
        int id = Integer.parseInt(JOptionPane.showInputDialog("ID"));
        String nome = JOptionPane.showInputDialog("Nome");
        String finalizada = JOptionPane.showInputDialog("Finalizada");

        Manutencao manEnt = new Manutencao(id, nome, Boolean.parseBoolean(finalizada));
        ControllerManutencao contMant = new ControllerManutencao();
        Manutencao manSaida = contMant.alterar(manEnt);
        JOptionPane.showMessageDialog(null, manSaida.toString());
    }

    private static void buscar() throws SQLException, ClassNotFoundException {
        int id = Integer.parseInt(JOptionPane.showInputDialog("ID"));
        Manutencao manEnt = new Manutencao(id);
        ControllerManutencao contMant = new ControllerManutencao();
        Manutencao manSaida = contMant.buscar(manEnt);
        JOptionPane.showMessageDialog(null, manSaida.toString());
    }

    private static void excluir() throws SQLException, ClassNotFoundException {
        int id = Integer.parseInt(JOptionPane.showInputDialog("ID"));
        Manutencao manEnt = new Manutencao(id);
        ControllerManutencao contMant = new ControllerManutencao();
        Manutencao manSaida = contMant.excluir(manEnt);
        JOptionPane.showMessageDialog(null, manSaida.toString());
    }

    private static void listar() throws SQLException, ClassNotFoundException {
        String nome = JOptionPane.showInputDialog("Nome");
        Manutencao manEnt = new Manutencao(nome);
        ControllerManutencao contMant = new ControllerManutencao();
        List<Manutencao> listaManutencao = contMant.listar(manEnt);
        for (Manutencao manSaida : listaManutencao) {
            JOptionPane.showMessageDialog(null, manSaida.toString());
        }
    }
}
