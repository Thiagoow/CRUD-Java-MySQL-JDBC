/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dm20241m.model.bean;

/**
 *
 * @author thiag
 */
public class Manutencao {
    private int id;
    private String nome;
    private boolean finalizada;

    public Manutencao(int id) {
        this.id = id;
    }

    public Manutencao(String nome) {
        this.nome = nome;
    }

    public Manutencao(String nome, boolean finalizada) {
        this.nome = nome;
        this.finalizada = finalizada;
    }

    public Manutencao(int id, String nome, boolean finalizada) {
        this.id = id;
        this.nome = nome;
        this.finalizada = finalizada;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public boolean isFinalizada() {
        return finalizada;
    }

    public void setFinalizada(boolean finalizada) {
        this.finalizada = finalizada;
    }

    @Override
    public String toString() {
        return "Manutencao{" + "id=" + id + ", nome=" + nome + ", finalizada=" + finalizada + '}';
    }
}
