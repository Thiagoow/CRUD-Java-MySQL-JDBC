/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dm20241m.model.bean;

/**
 *
 * @author thiag
 */
public class ManutencaoSistema {
    private int id;
    private int idM;
    private int idS;
    private String obs;
    private Manutencao manut;
    private Sistema sist;

    public ManutencaoSistema(int id) {
        this.id = id;
    }
    
    public ManutencaoSistema(String obs) {
        this.obs = obs;
    }

    public ManutencaoSistema(int idM, int idS, String obs) {
        this.idM = idM;
        this.idS = idS;
        this.obs = obs;
    }

    public ManutencaoSistema(int id, int idM, int idS, String obs) {
        this.id = id;
        this.idM = idM;
        this.idS = idS;
        this.obs = obs;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdM() {
        return idM;
    }

    public void setIdM(int idM) {
        this.idM = idM;
    }

    public int getIdS() {
        return idS;
    }

    public void setIdS(int idS) {
        this.idS = idS;
    }
    
        public String getObs() {
        return obs;
    }

    public void setObs(String obs) {
        this.obs = obs;
    }

    public Manutencao getManut() {
        return manut;
    }

    public void setManut(Manutencao manut) {
        this.manut = manut;
    }

    public Sistema getSist() {
        return sist;
    }

    public void setSist(Sistema sist) {
        this.sist = sist;
    }

    @Override
    public String toString() {
        return "ManutencaoSistema{" + "id=" + id + ", idM=" + idM + ", idS=" + idS + ", obs=" + obs + '}';
    }
}
