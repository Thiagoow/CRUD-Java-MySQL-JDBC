/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dm20241m.model.dao;

import dm20241m.model.bean.UsuarioSistema;
import dm20241m.util.ConexaoDb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author thiag
 */
public class DaoUsuarioSistema {
    private final Connection c;

    public DaoUsuarioSistema() throws SQLException, ClassNotFoundException {
        this.c = ConexaoDb.getConexaoMySQL();
    }

    public UsuarioSistema inserir(UsuarioSistema usEnt) throws SQLException {
        String sql = "INSERT INTO usuariossistemas (idU, idS, obs) VALUES (?, ?, ?)";

        PreparedStatement stmt = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

        stmt.setInt(1, usEnt.getIdU());
        stmt.setInt(2, usEnt.getIdS());
        stmt.setString(3, usEnt.getObs());

        stmt.executeUpdate();

        ResultSet rs = stmt.getGeneratedKeys();
        if (rs.next()) {
            int id = rs.getInt(1);
            usEnt.setId(id);
        }

        stmt.close();
        return usEnt;
    }

    public UsuarioSistema alterar(UsuarioSistema usEnt) throws SQLException {
        String sql = "UPDATE usuariossistemas SET idU = ?, idS = ?, obs = ? WHERE id = ?";

        PreparedStatement stmt = c.prepareStatement(sql);

        stmt.setInt(1, usEnt.getIdU());
        stmt.setInt(2, usEnt.getIdS());
        stmt.setString(3, usEnt.getObs());
        stmt.setInt(4, usEnt.getId());

        stmt.executeUpdate();
        stmt.close();

        return usEnt;
    }

    public UsuarioSistema buscar(int id) throws SQLException {
        String sql = "SELECT * FROM usuariossistemas WHERE id = ?";

        PreparedStatement stmt = c.prepareStatement(sql);
        stmt.setInt(1, id);

        ResultSet rs = stmt.executeQuery();
        UsuarioSistema us = null;
        if (rs.next()) {
            us = new UsuarioSistema(
                    rs.getInt("id"),
                    rs.getInt("idU"),
                    rs.getInt("idS"),
                    rs.getString("obs")
            );
        }

        rs.close();
        stmt.close();

        return us;
    }

    public List<UsuarioSistema> listar() throws SQLException {
        String sql = "SELECT * FROM usuariossistemas";

        PreparedStatement stmt = c.prepareStatement(sql);
        ResultSet rs = stmt.executeQuery();

        List<UsuarioSistema> lista = new ArrayList<>();
        while (rs.next()) {
            UsuarioSistema us = new UsuarioSistema(
                    rs.getInt("id"),
                    rs.getInt("idU"),
                    rs.getInt("idS"),
                    rs.getString("obs")
            );
            lista.add(us);
        }

        rs.close();
        stmt.close();

        return lista;
    }

    public void excluir(int id) throws SQLException {
        String sql = "DELETE FROM usuariossistemas WHERE id = ?";

        PreparedStatement stmt = c.prepareStatement(sql);
        stmt.setInt(1, id);

        stmt.executeUpdate();
        stmt.close();
    }
}