/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dm20241m.model.dao;

import dm20241m.model.bean.Sistema;
import dm20241m.util.ConexaoDb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author thiag
 */
public class DaoSistema {
    private final Connection c;

    public DaoSistema() throws SQLException, ClassNotFoundException {
        this.c = ConexaoDb.getConexaoMySQL();
    }

    public Sistema inserir(Sistema sisEnt) throws SQLException {
        String sql = "insert into sistemas (nome, servidor, versao, status) values (?, ?, ?, ?)";

        PreparedStatement stmt = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

        stmt.setString(1, sisEnt.getNome());
        stmt.setString(2, sisEnt.getServidor());
        stmt.setString(3, sisEnt.getVersao());
        stmt.setString(4, sisEnt.getStatus());

        stmt.executeUpdate();
        ResultSet rs = stmt.getGeneratedKeys();
        if (rs.next()) {
            int id = rs.getInt(1);
            sisEnt.setId(id);
        }
        stmt.close();
        return sisEnt;
    }

    public Sistema alterar(Sistema sisEnt) throws SQLException {
        String sql = "UPDATE sistemas SET nome=?, servidor=?, versao=?, status=? WHERE id=?";

        PreparedStatement stmt = c.prepareStatement(sql);

        stmt.setString(1, sisEnt.getNome());
        stmt.setString(2, sisEnt.getServidor());
        stmt.setString(3, sisEnt.getVersao());
        stmt.setString(4, sisEnt.getStatus());
        stmt.setInt(5, sisEnt.getId());

        stmt.executeUpdate();

        stmt.close();
        return sisEnt;
    }

    public Sistema excluir(Sistema sisEnt) throws SQLException {
        String sql = "DELETE FROM sistemas WHERE id=?";

        PreparedStatement stmt = c.prepareStatement(sql);

        stmt.setInt(1, sisEnt.getId());

        stmt.executeUpdate();

        stmt.close();
        return sisEnt;
    }

    public Sistema buscar(Sistema sisEnt) throws SQLException {
        String sql = "SELECT * FROM sistemas WHERE id=?";

        PreparedStatement stmt = c.prepareStatement(sql);
        stmt.setInt(1, sisEnt.getId());

        ResultSet rs = stmt.executeQuery();

        Sistema sisSaida = null;
        if (rs.next()) {
            sisSaida = new Sistema(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("servidor"),
                    rs.getString("versao"),
                    rs.getString("status")
            );
        }

        stmt.close();
        return sisSaida;
    }

    public List<Sistema> listar(Sistema sisEnt) throws SQLException {
        List<Sistema> sistemas = new ArrayList<>();

        String sql = "SELECT * FROM sistemas where nome like ?";
        PreparedStatement stmt = c.prepareStatement(sql);
                // seta os valores
        stmt.setString(1,"%" + sisEnt.getNome() + "%");

        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            Sistema sis = new Sistema(
                rs.getInt("id"),
                rs.getString("nome"),
                rs.getString("servidor"),
                rs.getString("versao"),
                rs.getString("status")
            );
            sistemas.add(sis);
        }

        rs.close();
        stmt.close();
        return sistemas;
    }
}