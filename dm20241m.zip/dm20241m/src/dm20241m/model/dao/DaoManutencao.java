/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dm20241m.model.dao;

import dm20241m.model.bean.Manutencao;
import dm20241m.util.ConexaoDb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author thiag
 */
public class DaoManutencao {
    
    private final Connection c;

    public DaoManutencao() throws SQLException, ClassNotFoundException {
        this.c = ConexaoDb.getConexaoMySQL();
    }

    public Manutencao inserir(Manutencao manEnt) throws SQLException {
        String sql = "insert into manutencao (nome, finalizada) values (?, ?)";

        PreparedStatement stmt = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

        stmt.setString(1, manEnt.getNome());
        stmt.setBoolean(2, manEnt.isFinalizada());

        stmt.executeUpdate();
        ResultSet rs = stmt.getGeneratedKeys();
        if (rs.next()) {
            int id = rs.getInt(1);
            manEnt.setId(id);
        }
        stmt.close();
        return manEnt;
    }

    public Manutencao alterar(Manutencao manEnt) throws SQLException {
        String sql = "UPDATE manutencao SET nome=?, finalizada=? where id = ?";

        PreparedStatement stmt = c.prepareStatement(sql);

        stmt.setString(1, manEnt.getNome());
        stmt.setBoolean(2, manEnt.isFinalizada());
        stmt.setInt(3, manEnt.getId());

        stmt.executeUpdate();

        stmt.close();
        return manEnt;
    }

    public Manutencao excluir(Manutencao manEnt) throws SQLException {
        String sql = "DELETE FROM manutencao WHERE id=?";

        PreparedStatement stmt = c.prepareStatement(sql);

        stmt.setInt(1, manEnt.getId());

        stmt.executeUpdate();

        stmt.close();
        return manEnt;
    }

    public Manutencao buscar(Manutencao manEnt) throws SQLException {
        String sql = "SELECT * FROM manutencao WHERE id=?";

        PreparedStatement stmt = c.prepareStatement(sql);
        stmt.setInt(1, manEnt.getId());

        ResultSet rs = stmt.executeQuery();

        Manutencao manSaida = null;
        if (rs.next()) {
            manSaida = new Manutencao(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getBoolean("finalizada")
            );
        }

        stmt.close();
        return manSaida;
    }

    public List<Manutencao> listar(Manutencao manEnt) throws SQLException {
        List<Manutencao> manutencoes = new ArrayList<>();

        String sql = "SELECT * FROM manutencao where nome like ?";
        PreparedStatement stmt = c.prepareStatement(sql);
                // seta os valores
        stmt.setString(1,"%" + manEnt.getNome() + "%");

        ResultSet rs = stmt.executeQuery();

        while (rs.next()) {
            Manutencao manut = new Manutencao(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getBoolean("finalizada")
            );
            manutencoes.add(manut);
        }

        rs.close();
        stmt.close();
        return manutencoes;
    }
}
