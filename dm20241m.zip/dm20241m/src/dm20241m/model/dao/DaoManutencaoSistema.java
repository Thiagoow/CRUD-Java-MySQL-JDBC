/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dm20241m.model.dao;

import dm20241m.model.bean.ManutencaoSistema;
import dm20241m.util.ConexaoDb;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author thiag
 */
public class DaoManutencaoSistema {
    private final Connection c;

    public DaoManutencaoSistema() throws SQLException, ClassNotFoundException {
        this.c = ConexaoDb.getConexaoMySQL();
    }

    public ManutencaoSistema inserir(ManutencaoSistema usEnt) throws SQLException {
        String sql = "INSERT INTO manutencaosistemas (idM, idS, obs) VALUES (?, ?, ?)";

        PreparedStatement stmt = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

        stmt.setInt(1, usEnt.getIdM());
        stmt.setInt(2, usEnt.getIdS());
        stmt.setString(3, usEnt.getObs());

        stmt.executeUpdate();

        ResultSet rs = stmt.getGeneratedKeys();
        if (rs.next()) {
            int id = rs.getInt(1);
            usEnt.setId(id);
        }

        stmt.close();
        return usEnt;
    }

    public ManutencaoSistema alterar(ManutencaoSistema usEnt) throws SQLException {
        String sql = "UPDATE manutencaosistemas SET idM = ?, idS = ?, obs = ? WHERE id = ?";

        PreparedStatement stmt = c.prepareStatement(sql);

        stmt.setInt(1, usEnt.getIdM());
        stmt.setInt(2, usEnt.getIdS());
        stmt.setInt(3, usEnt.getId());
        stmt.setString(4, usEnt.getObs());

        stmt.executeUpdate();
        stmt.close();

        return usEnt;
    }

    public ManutencaoSistema buscar(ManutencaoSistema msEnt) throws SQLException {
        String sql = "select * from manutencaosistemas WHERE id = ?";
        PreparedStatement stmt = this.c.prepareStatement(sql);
            // seta os valores
            stmt.setInt(1,msEnt.getId());
            // executa
            ResultSet rs = stmt.executeQuery();
            ManutencaoSistema disciSaida = null;
            while (rs.next()) {      
                disciSaida = new ManutencaoSistema(
                    rs.getInt(1),
                    rs.getInt(2),
                    rs.getInt(3),
                    rs.getString(4));
            }
            stmt.close();
        return disciSaida;
    }

    public List<ManutencaoSistema> listar(ManutencaoSistema msEnt) throws SQLException {
        // discis: array armazena a lista de registros
        List<ManutencaoSistema> list = new ArrayList<>();
        
        String sql = "select * from manutencaosistemas where obs like ?";
        PreparedStatement stmt = this.c.prepareStatement(sql);
        // seta os valores
        stmt.setString(1,"%" + msEnt.getObs()+ "%");
        
        ResultSet rs = stmt.executeQuery();
        
        while (rs.next()) {      
            // criando o objeto Usuario
            ManutencaoSistema user = new ManutencaoSistema(
                rs.getInt(1),
                rs.getInt(2),
                rs.getInt(3),
                rs.getString(4)
            );
            // adiciona o disci à lista de discis
            list.add(user);
        }
        
        rs.close();
        stmt.close();
        return list;
    }

    public void excluir(int id) throws SQLException {
        String sql = "DELETE FROM manutencaosistemas WHERE id = ?";

        PreparedStatement stmt = c.prepareStatement(sql);
        stmt.setInt(1, id);

        stmt.executeUpdate();
        stmt.close();
    }
}
